package com.MavenMarioProject.MarioTestProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarioTestProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
