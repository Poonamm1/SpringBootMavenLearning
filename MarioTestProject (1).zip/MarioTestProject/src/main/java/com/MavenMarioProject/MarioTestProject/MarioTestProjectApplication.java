package com.MavenMarioProject.MarioTestProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarioTestProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarioTestProjectApplication.class, args);
	}

}
